import requests
from projectshop64.settings import  EMAIL_SERVICE_ENDPOINT ,EMAIL_SENDER_NAME ,EMAIL_SENDER_EMAIL,EMAIL_API_KEY
import json

def sendEmail(name, email, subject, htmlContent):
    def send_simple_message():
        return requests.post(
            "https://api.mailgun.net/v3/sandbox0e3699ed92a647bf8d46899fda6dc612.mailgun.org/messages",
            auth=("api", "a6291b132f20153e5bbb59e60d4e469e-0f472795-46e70cc0"),
            data={"from": "Rinakshi <"+name+"@sandbox0e3699ed92a647bf8d46899fda6dc612.mailgun.org>",
                  "to": ["rinakshisahu1995@gmail.com"],
                  "subject": subject,
                  "html": htmlContent})
    response= sendEmail(email='rinakshisahu1995@gmail.com',
              name="RINAKSHI SAHU",
              subject='test',
              htmlContent='<h1>Hello....</h1>')
    return response
