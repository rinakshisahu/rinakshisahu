from django.db import models
class Product(models.Model):
    name=models.CharField()
    description=models.CharField()
    price=models.IntegerField(default=0)
    discount=models.IntegerField(default=0)
    file=models.FileField(upload_to='upload/files')
    thumbnail=models.FileField(upload_to='upload/thumbnails')
    link=models.CharField(null=True)
    fileSize=models.CharField(null=True)
class ProductImages(models.Model):
    product=models.ForeignKey(Product,default=None,on_delete=models.CASCADE)
    image=models.ImageField(upload_to='uploads/images' , blank=True)
