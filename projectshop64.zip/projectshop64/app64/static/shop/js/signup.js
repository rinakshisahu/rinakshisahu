var token = null
var loading = null
window.onload = function(){
    loading = document.getElementById('loading')
}
function validate(event){
    console.log('form submission')

    var error = document.getElementById('message')
    var message = null
    var form=event.target

    var values=form.elements
    token=values.csrfmiddlewaretoken.value

    var email=values.email.value;
    var name=values.name.value;

    message=validateForm(form)

    if(message){
        error.innerHTML = message
        error.hidden=false
    }else{
        error.innerHTML = " "
        error.hidden=true

        sendEmail(name,email,token)
    }


    console.log({
        name,phone,email,password,repassword})

    event.stopPropagation()
    return false
}
function validateForm(form) {
    var values = form.elements
    var name = values.name.value
    token = values.csrfmiddlewaretoken.value
    var message = null
    var phone = values.phone.value
    var email = values.email.value
    var password = values.password.value
    var repassword = values.repassword.value

    if (!name.trim()) {
        message = "name is required."
    } else if (!email.trim()) {
        message = "email is required."
    }
    else if (!password.trim()) {
        message = "password is required."
    }
    else if (!repassword.trim()) {
        message = "enter password again."
    }
    return message
}
function sendEmail(name, email, token) {
    console.log(name, email, token)
    loading.hidden = false
    $.ajax({
        method: "POST",
        url: "/send-email",
        data: {name: "name", email: "email", token:'csrfmiddlewaretoken'}
    })
        .done(function (msg) {
            alert("Data Saved: " + msg)
            loading.hidden = true
            showOtpInput()
        }).fail(function (err) {
        loading.hidden = true
        alert('cant send email')
    })
}
function showOtpInput() {
    var otpInput = document.getElementById('VerificationInput')
    var submit = document.getElementById('submitButton')
    var verifyButton = document.getElementById('VerifyButton')

    otpInput.hidden = false
    submit.hidden = true
    verifyButton.hidden = false
}
function verifyCode(Code, otp) {
    var codeInput = document.getElementById('code')
    var code = codeInput.value
    loading.hidden = false
    $.ajax({
        method: "POST",
        url: "/verify",
        data: {'code': code, 'csrfmiddlewaretoken': token}
    })
        .done(function (msg) {
            #// alert("code verified: " + msg)
                loading.hidden = true
            submitForm()
        }).fail(function (err) {
        loading.hidden = true
        alert('code is invalid')
    })
}
function submitForm() {
        try{
            var form = document.getElementById('form')
            var message = validateForm(form)
        if (message) {
        } else {
            form.submit()
        }
        }catch(err){
        console.log(err)}
}





