from django.apps import AppConfig


class App64Config(AppConfig):
    name = 'app64'
