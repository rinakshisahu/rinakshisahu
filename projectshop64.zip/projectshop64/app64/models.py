from django.db import models


class Product(models.Model):
    name = models.CharField(max_length=50)
    description = models.CharField(max_length=500)
    price = models.IntegerField(default=0)
    active = models.BooleanField(default=True)
    discount = models.IntegerField(default=0)
    file = models.FileField(upload_to='upload/files',blank=True)
    thumbnail = models.FileField(upload_to='upload/thumbnails')
    link = models.CharField(null=True,blank=True,max_length=200)
    fileSize = models.CharField(null=True,max_length=10)


class ProductImages(models.Model):
    product = models.ForeignKey(Product, default=None, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='uploads/images', blank=True)
class User(models.Model):
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=100)
    active = models.BooleanField(default=True)
    password = models.CharField(max_length=300)
    phone = models.CharField(max_length=10)




