from django.contrib import admin
from app64.models import ProductImages,Product,User


class ProductImageModel(admin.StackedInline):
    model=ProductImages
class ProductModel(admin.ModelAdmin):
    list_display = ['id','name','description','get_price','get_discount','get_sale_price','file','thumbnail']
    inlines = [ProductImageModel]
    def get_sale_price(self,obj):
        return ((obj.price)-(obj.price * (obj.discount/100)))


    def get_price(self,obj):
        return '₹ ' + str(obj.price)
    def get_discount(self,obj):
        return  str(obj.discount)+ "%"
    get_sale_price.short_description="sale price"
    get_discount.short_description="Discount"
    get_price.short_description="Price"




admin.site.register(Product,ProductModel)
admin.site.register(User)
